import os
from werkzeug.wrappers import Request, Response

class middleware():
    '''
        Base middleware
    '''

    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        request = Request(environ)

        if request.method == 'OPTIONS':
            res = Response(status=204)
            return res(environ, start_response)

        app_api_key = os.getenv("API_KEY")
        api_key = request.headers.get("api_key")

        if not api_key:
            res = Response(u'Authorization failed: API key missing', mimetype='text/plain', status=401)
            return res(environ, start_response)
        
        if app_api_key != api_key:
            res = Response(u'Authorization failed', mimetype= 'text/plain', status=401)
            return res(environ, start_response)
        
        return self.app(environ, start_response)

        