def response(body: dict, code = 400):
    return {
        "body": body,
        "code": code
    }