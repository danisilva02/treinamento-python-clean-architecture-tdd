import secrets
import random
import string

def securty_code_generator():
    return secrets.randbelow(900000) + 100000

def password_generator(length=8):
    characters = string.ascii_letters + string.digits
    password = ''.join(random.choice(characters) for _ in range(length))
    return password