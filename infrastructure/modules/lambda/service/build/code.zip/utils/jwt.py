import os
import jwt
import datetime
from dotenv import load_dotenv

load_dotenv()

SECRET_KEY = os.environ['JWT_SECRET_KEY']

def generate_jwt(user_id):
    expiration_time = datetime.datetime.utcnow() + datetime.timedelta(hours=24)
    
    payload = {
        'user_id': user_id,
        'exp': expiration_time
    }
    
    token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')
    
    return token

def decode_jwt(token):
    try:
        decoded = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return decoded
    except jwt.ExpiredSignatureError:
        return False # 'Token expirado!'
    except jwt.InvalidTokenError:
        return False # 'Token inválido!'