import os
from slack_sdk import WebClient
from dotenv import load_dotenv

load_dotenv()

client = WebClient(token=os.environ['SLACK_BOT_TOKEN'])

def message(lambda_name: str, aws_request_id: str, message: str):
  blocks = [
    {
      "type": "header",
      "text": {
        "type": "plain_text",
        "text": "Lambda Falhou :x:",
        "emoji": True
      }
    },
    {
      "type": "divider"
    },
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": f"*Lambda Name:* {lambda_name}\n*AWS Lambda Request:* {aws_request_id}\n*Message:* {message}"
      },
      "accessory": {
        "type": "image",
        "image_url": "https://cdn.stokado.com/data/aws_lambda.webp",
        "alt_text": "computer thumbnail"
      }
    },
  ]

  client.chat_postMessage(channel='#devops-data', blocks=blocks)