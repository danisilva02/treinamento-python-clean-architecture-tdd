import os
import resend
from dotenv import load_dotenv

# Template
from infra.repository.email.template import compose_template

load_dotenv()

resend.api_key = os.getenv('RESEND_API_KEY')

class EmailRepo():

    def perform(self, email, subject, title, message):
        try:
            r = resend.Emails.send({
                "from": "Acme <onboarding@resend.dev>",
                # "from": "Acme <no-reply@stokado.com.br>",
                "to": email,
                "subject": subject,
                "html": compose_template(
                    title=title,
                    message=message,
                )
            })
        except Exception as e:
            print(e)
            raise e