import json

class ACLRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = """
            INSERT INTO "acl" (
                id,
                name,
                status,
                created_at,
                updated_at,
                menu_config,
                user_id
            ) VALUES (
                %s, %s, %s, NOW(), NOW(), %s, %s
            );
        """

        values = (
            str(data.get("id")),
            data.get("name"),
            data.get("status"),
            json.dumps(data.get("menu_config")) if data.get("menu_config") else None,
            str(data.get("user_id"))
        )

        try:
            cur.execute(query, values)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()