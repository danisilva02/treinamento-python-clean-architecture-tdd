class UserAuthRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = f"""
            INSERT INTO "user_auth" (
                id,
                password,
                created_at,
                updated_at,
                user_id
            ) VALUES (
                '{data.get("id")}',
                '{data.get("password")}',
                NOW(),
                NOW(),
                '{data.get("user_id")}'
            );
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def get_by_user_id_and_password_hash(self, user_id: str, password: str):
        cur = self.connection.cursor()

        query = f"""
            SELECT
                *
            FROM "user_auth"
            WHERE 1=1
                AND password = '{password}'
                AND user_id = '{user_id}';
        """
        
        print(query)

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()
            
    def update_password(self, user_id: str, password: str):
        cur = self.connection.cursor()

        query = f"""
            UPDATE "user_auth"
            SET
                password = '{password}'
            WHERE 1=1
            AND user_id = '{user_id}'
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()