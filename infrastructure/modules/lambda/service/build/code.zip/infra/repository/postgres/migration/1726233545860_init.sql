-- Tabela: user
CREATE TABLE IF NOT EXISTS "user" (
    id VARCHAR(36) PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    national_id VARCHAR(255) UNIQUE,
    national_id_plus VARCHAR(255) UNIQUE,
    uid VARCHAR(255) NOT NULL UNIQUE,
    step VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    provider VARCHAR(255) NOT NULL,
    skill VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    profile_id VARCHAR(36) NOT NULL UNIQUE,
    acl_id VARCHAR(36) NOT NULL UNIQUE,
    contract_id VARCHAR(36) UNIQUE,
    two_factor_id VARCHAR(36) UNIQUE
);

-- Tabela: user_auth - Temporary
CREATE TABLE IF NOT EXISTS "user_auth" (
    id VARCHAR(36) PRIMARY KEY,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: contract
CREATE TABLE IF NOT EXISTS "contract" (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255),
    type VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    start_date TIMESTAMP DEFAULT NOW(),
    end_date TIMESTAMP,
    status VARCHAR(255),
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: alert
CREATE TABLE IF NOT EXISTS "alert" (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255),
    type VARCHAR(255),
    status VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: message
CREATE TABLE IF NOT EXISTS "message" (
    id VARCHAR(36) PRIMARY KEY,
    text VARCHAR(255),
    target VARCHAR(255),
    type VARCHAR(255),
    status VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: profile
CREATE TABLE IF NOT EXISTS "profile" (
    id VARCHAR(36) PRIMARY KEY,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    nickname VARCHAR(255),
    country VARCHAR(255),
    language VARCHAR(255),
    birth_date VARCHAR(255),
    phone_number VARCHAR(255) UNIQUE,
    address JSONB,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: bank_account
CREATE TABLE IF NOT EXISTS "bank_account" (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255),
    digit VARCHAR(10),
    agency VARCHAR(10),
    account VARCHAR(255),
    pix_target VARCHAR(255),
    pix_value VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: acl
CREATE TABLE IF NOT EXISTS "acl" (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    menu_config JSONB,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: two_factor
CREATE TABLE IF NOT EXISTS "two_factor" (
    id VARCHAR(36) PRIMARY KEY,
    provider VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    authId INTEGER NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP
);

-- Tabela: company
CREATE TABLE IF NOT EXISTS "company" (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    national_id VARCHAR(255) NOT NULL UNIQUE,
    address VARCHAR(255) NOT NULL,
    key VARCHAR(255) NOT NULL,
    status VARCHAR(255) NOT NULL,
    nickname VARCHAR(255),
    social_reason VARCHAR(255),
    phone_number VARCHAR(255),
    email VARCHAR(255),
    contact VARCHAR(255),
    country VARCHAR(255),
    language VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP
);

-- Tabela: security
CREATE TABLE IF NOT EXISTS "security" (
    id VARCHAR(36) PRIMARY KEY,
    type VARCHAR(255),
    status VARCHAR(255),
    code VARCHAR(255),
    provider VARCHAR(255),
    expiration_at TIMESTAMP NOT NULL DEFAULT NOW(),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: document
CREATE TABLE IF NOT EXISTS "document" (
    id VARCHAR(36) PRIMARY KEY,
    type VARCHAR(255),
    name_file VARCHAR(255),
    status VARCHAR(255),
    description VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: announcement
CREATE TABLE IF NOT EXISTS "announcement" (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) REFERENCES "user"(id),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    description VARCHAR(255) NOT NULL,
    title VARCHAR(255) NOT NULL,
    address JSONB,
    value FLOAT NOT NULL,
    daily BOOLEAN NOT NULL,
    discount BOOLEAN DEFAULT FALSE,
    discount_value FLOAT DEFAULT 0,
    publish BOOLEAN DEFAULT FALSE,
    reserved BOOLEAN DEFAULT FALSE,
    space_type VARCHAR(255),
    space_size FLOAT NOT NULL,
    space_resources JSONB NOT NULL,
    access_type VARCHAR(255),
    access_day JSONB,
    lnglat POINT
);

-- Tabela: announcement_images
CREATE TABLE IF NOT EXISTS "announcement_images" (
    id VARCHAR(36) PRIMARY KEY,
    name_file VARCHAR(255),
    status VARCHAR(255),
    description VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    announcement_id VARCHAR(36) REFERENCES "announcement"(id)
);

-- Tabela: announcement_reserved
CREATE TABLE IF NOT EXISTS "announcement_reserved" (
    id VARCHAR(36) PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    status VARCHAR(255) NOT NULL,
    description_guest VARCHAR(255),
    description_guardian VARCHAR(255),
    days_rented INTEGER NOT NULL,
    announcement_id VARCHAR(36) REFERENCES "announcement"(id),
    metadata JSONB,
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: reserved_event
CREATE TABLE IF NOT EXISTS "reserved_event" (
    id VARCHAR(36) PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    type VARCHAR(255),
    user_email VARCHAR(255),
    metadata JSONB,
    announcement_reserved_id VARCHAR(36) REFERENCES "announcement_reserved"(id)
);

-- Tabela: chat channel
CREATE TABLE IF NOT EXISTS "chat_channel" (
    id VARCHAR(36) PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    message JSONB,
    announcement_id VARCHAR(36) REFERENCES "announcement"(id),
    user_id VARCHAR(36) REFERENCES "user"(id)
);

-- Tabela: chat message
CREATE TABLE IF NOT EXISTS "chat_message" (
    id VARCHAR(36) PRIMARY KEY,
    created_at TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMP,
    message JSONB,
    chat_channel_id VARCHAR(36) REFERENCES "chat_channel"(id)
);

-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ALTER TABLE "user" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "contract" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "message" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "profile" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "acl" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "two_factor" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "company" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "security" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "document" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "announcement" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "announcement_images" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "announcement_reserved" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "reserved_event" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "chat" ALTER COLUMN id SET DEFAULT uuid_generate_v4();
-- ALTER TABLE "bank_account" ALTER COLUMN id SET DEFAULT uuid_generate_v4();

