class Repo():
    def __init__(self, connection):
        self.connection = connection

    def perform(self):
        cur = self.connection
        cur.execute("SELECT version();")
        version = cur.fetchone()
        cur.close()
        return {"status": "ok", "version": version}
        
