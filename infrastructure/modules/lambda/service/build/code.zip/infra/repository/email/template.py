def compose_template(title: str, message: str):
    return f"""
        <!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
        <html lang="en">
        <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="format-detection" content="telephone=no">
        <title>Stokado</title>
        <style type="text/css">
        body {{
            margin: 0;
            padding: 0;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%;
        }}
        table {{
            border-spacing: 0;
        }}
        table td {{
            border-collapse: collapse;
        }}
        .ExternalClass {{
            width: 100%;
        }}
        .ExternalClass, .ExternalClass p, .ExternalClass span, .ExternalClass font, .ExternalClass td, .ExternalClass div {{
            line-height: 100%;
        }}
        .ReadMsgBody {{
            width: 100%;
            background-color: #ebebeb;
        }}
        table {{
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }}
        img {{
            -ms-interpolation-mode: bicubic;
        }}
        .img-header {{
            margin-top: 11px;
        }}
        .img-responsive {{
            max-width: 100%;height: auto;display:block;vertical-align: middle;
        }}
        .yshortcuts a {{
            border-bottom: none !important;
        }}
        @media screen and (max-width: 599px) {{
            .force-row, .container {{
                width: 100% !important;
                max-width: 100% !important;
            }}
        }}
        @media screen and (max-width: 400px) {{
            .container-padding {{
                padding-left: 12px !important;
                padding-right: 12px !important;
            }}
        }}
        .ios-footer a {{
            color: #aaaaaa !important;
            text-decoration: underline;
        }}
        hr {{
            background-color: #e8e8e8;
            border: 0;
            height: 1px;
        }}
        </style>
        </head>
        <body bgcolor="#F8F8F8" leftmargin="0" marginheight="0" marginwidth="0" style="margin:0; padding:0;" topmargin="0">
        <table bgcolor="#F8F8F8" border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
        <tbody>
        <tr>
        <td align="center" bgcolor="#F8F8F8" style="background-color: #F8F8F8;" valign="top"><br />
        <table border="0" cellpadding="0" cellspacing="0" class="container" style="width:600px;max-width:600px" width="600">
            <tbody>
            <tr>
                <td align="left" class="container-padding header" style="font-family:Helvetica, Arial, sans-serif;font-size:24px;font-weight:bold;padding-bottom:12px;color:#FFFFFF;padding-left:24px;padding-right:24px; background-color: #FFF; height: 8vh;border-radius: 8px 8px 0px 0px;">
                <span class="sg-image" style="float: none; display: block; text-align: center;">
                <a href="https://www.stokado.com.br/images/logo.png">
                <img height="62" src="https://www.stokado.com.br/images/logo.png" style="margin-top: 11px; max-width: 90%; height: 62px; vertical-align: middle; width: 90%;" width="90%" />
                </a></span></td>
            </tr>
            <tr>
                <td align="left" class="container-padding content" style="padding-left:24px;padding-right:24px;padding-top:12px;padding-bottom:12px;background-color:#ffffff">&nbsp;
                <div class="title" style="font-family:Helvetica, Arial, sans-serif;font-size:20px;color:#444444">{title}</div>
                &nbsp;

                <div class="body-text" style="font-family:Helvetica, Arial, sans-serif;font-size:14px;line-height:20px;text-align:left;color:#333333">
                <p align="justify" style="white-space: pre-line">{message}</p>
                &nbsp;

                <center><br />
                <a href="stokado://deeplink.com.app.stokado" style="border-style: solid; border-width :0px; text-decoration: none; padding : 12px; border-color: #000000; background-color: #ff9001; color: #FFFFFF; border-radius: 5px;">Acessar o aplicativo</a><br />
                <br />
                &nbsp;</center>
                </div>
                </td>
            </tr>
            <tr>
                <td align="left" class="container-padding footer-text" style="font-family:Helvetica, Arial, sans-serif;font-size:12px;line-height:16px;color:#aaaaaa;padding-left:24px;padding-right:24px"><br />
                E-mail recebido de acordo com o cadastro de pol&iacute;tica da empresa.<br />
                Essa mensagem &eacute; enviada automaticamente, favor n&atilde;o responder.<br />
                &nbsp;
                <center><br />
                <br />
                <strong>Stokado</strong><br />
                <a href="https://www.stokado.com.br/" style="color:#ff9001">https://www.stokado.com.br/</a>
                <center><br />
                &nbsp;</center>
                </center>
                </td>
            </tr>
            </tbody>
        </table>
        </td>
        </tr>
        </tbody>
        </table>
        </body>
        </html>
    """
