class UserRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = f"""
            INSERT INTO "user" (
                id,
                email,
                national_id,
                national_id_plus,
                uid,
                step,
                status,
                provider,
                skill,
                created_at,
                updated_at,
                profile_id,
                acl_id,
                contract_id,
                two_factor_id
            ) VALUES (
                '{data.get("id")}',
                '{data.get("email")}',
                {f"'{data.get('national_id')}'" if data.get('national_id') else 'NULL'},
                {f"'{data.get('national_id_plus')}'" if data.get('national_id_plus') else 'NULL'},
                {f"'{data.get('uuid')}'" if data.get('uuid') else 'NULL'},
                '{data.get("step")}',
                '{data.get("status")}',
                '{data.get("provider")}',
                {f"'{data.get('skill')}'" if data.get('skill') else 'NULL'},
                NOW(),
                NOW(),
                '{data.get("profile_id")}',
                '{data.get("acl_id")}',
                {f"'{data.get('contract_id')}'" if data.get('contract_id') else 'NULL'},
                {f"'{data.get('two_factor_id')}'" if data.get('two_factor_id') else 'NULL'}
            );
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def update_status_finished(self, id: str):
        cur = self.connection.cursor()

        query = f"""
            UPDATE "user"
            SET
                step = 'FINISHED'
            WHERE 1=1
            AND id = '{id}'
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def get(self):
        cur = self.connection.cursor()

        query = f"""
            SELECT
                u.*,
                a.name AS acl_name
            FROM "user" u
            LEFT JOIN "acl" a ON a.user_id = u.id;
        """

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            raise e
        finally:
            cur.close()

    def get_by_id(self, id: str):
        cur = self.connection.cursor()

        query = f"""
            SELECT
                u.*,
                a.name AS acl_name
            FROM "user" u
            LEFT JOIN "acl" a ON a.user_id = u.id
            WHERE u.id = '{id}';
        """

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            raise e
        finally:
            cur.close()

    def get_by_email(self, email: str):
        cur = self.connection.cursor()

        query = f"""SELECT * FROM "user" WHERE email = '{email}';"""

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            raise e
        finally:
            cur.close()
