class SecurityRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = f"""
            INSERT INTO "security" (
                id,
                type,
                status,
                code,
                provider,
                expiration_at,
                created_at,
                updated_at,
                user_id
            ) VALUES (
                '{data.get("id")}',
                {f"'{data.get('type')}'" if data.get('type') else 'NULL'},
                {f"'{data.get('status')}'" if data.get('status') else 'NULL'},
                {f"'{data.get('code')}'" if data.get('code') else 'NULL'},
                'RESEND',
                {f"'{data.get('expiration_at')}'" if data.get('expiration_at') else "NOW() + INTERVAL '10 minutes'"},
                NOW(),
                NOW(),
                '{data.get("user_id")}'
            );
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def valid_code(self, user_id: str, code: str, security_type: str):
        cur = self.connection.cursor()

        query = f"""
            SELECT
                *
            FROM "security"
            WHERE 1=1
                AND expiration_at > NOW() - INTERVAL '10 minutes'
                AND code = '{code}'
                AND user_id = '{user_id}'
                AND type = '{security_type}';
        """

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def new_code(self, user_id, code, security_type: str):
        cur = self.connection.cursor()

        query = f"""
            UPDATE "security"
            SET
                code = '{code}',
                expiration_at = NOW() + INTERVAL '10 minutes',
                type = '{security_type}'
            WHERE 1=1
            AND user_id = '{user_id}'
            AND status = 'AWAIT';
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def confirm_code(self, user_id, code, security_type: str):
        cur = self.connection.cursor()

        query = f"""
            UPDATE "security"
            SET
                status = 'COMPLETED'
            WHERE 1=1
            AND user_id = '{user_id}'
            AND code = '{code}'
            AND status = 'AWAIT'
            AND type = '{security_type}';
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()

    def validated_code(self, user_id):
        cur = self.connection.cursor()

        query = f"""
            SELECT
                *
            FROM "security"
            WHERE 1=1
                AND user_id = '{user_id}'
                AND status = 'COMPLETED';
        """

        try:
            cur.execute(query)
            rows = cur.fetchall()
            column_names = [desc[0] for desc in cur.description]
            results = [dict(zip(column_names, row)) for row in rows]
            return results
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()
