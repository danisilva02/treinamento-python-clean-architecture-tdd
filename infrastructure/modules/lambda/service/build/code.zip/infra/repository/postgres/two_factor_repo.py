class TwoFactorRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = f"""
            INSERT INTO "two_factor" (
                id,
                provider,
                status,
                authId,
                created_at,
                updated_at
            ) VALUES (
                '{data.get("id")}',
                '{data.get("provider")}',
                '{data.get("status")}',
                {data.get("authId")},
                NOW(),
                NOW()
            );
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()