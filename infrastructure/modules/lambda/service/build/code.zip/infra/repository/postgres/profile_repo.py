import json

class ProfileRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = """
            INSERT INTO "profile" (
                id,
                first_name,
                last_name,
                nickname,
                country,
                language,
                birth_date,
                phone_number,
                address,
                created_at,
                updated_at,
                user_id
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), NOW(), %s
            );
        """

        values = (
            str(data.get("id")),
            data.get("first_name"),
            data.get("last_name") if data.get("last_name") else None,
            data.get("nickname") if data.get("nickname") else None,
            data.get("country") if data.get("country") else None,
            data.get("language") if data.get("language") else None,
            data.get("birth_date") if data.get("birth_date") else None,
            data.get("phone_number") if data.get("phone_number") else None,
            json.dumps(data.get("address")) if data.get("address") else None,
            str(data.get("user_id"))
        )

        try:
            cur.execute(query, values)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()