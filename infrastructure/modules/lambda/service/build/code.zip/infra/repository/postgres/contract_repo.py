class ContractRepo():
    def __init__(self, connection):
        self.connection = connection

    def insert(self, data: dict):
        cur = self.connection.cursor()

        query = f"""
            INSERT INTO "contract" (
                id,
                name,
                type,
                created_at,
                updated_at,
                start_date,
                end_date,
                status,
                user_id
            ) VALUES (
                '{data.get("id")}',
                {f"'{data.get('name')}'" if data.get('name') else 'NULL'},
                {f"'{data.get('type')}'" if data.get('type') else 'NULL'},
                NOW(),
                NOW(),
                {f"'{data.get('start_date')}'" if data.get('start_date') else 'NOW()'},
                {f"'{data.get('end_date')}'" if data.get('end_date') else 'NOW()'},
                {f"'{data.get('status')}'" if data.get('status') else 'NULL'},
                '{data.get("user_id")}'
            );
        """

        try:
            cur.execute(query)
            self.connection.commit()
            return cur.rowcount
        except Exception as e:
            print(e)
            self.connection.rollback()
            raise e
        finally:
            cur.close()