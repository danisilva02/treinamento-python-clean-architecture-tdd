# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.security_repo import SecurityRepo
from infra.repository.postgres.user_auth_repo import UserAuthRepo

# Utils
from utils.response_domain import response
from utils.jwt import generate_jwt
from utils.md5 import generate_hash

def validator_params(params: dict):
    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )
    
    if not "old_password" in params:
        return response(
            body={
                "message": "Password antigo é obrigatório"
            }
        )
    
    if not "new_password" in params:
        return response(
            body={
                "message": "Password novo é obrigatório"
            }
        )

    return None

class ChangePassword():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_email(email=params.get("email"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )

        if get_user[0]["status"] != "ACTIVE":
            return response(
                body={
                    "message": "Usuário sem permissão"
                },
                code=403
            )

        old_password_hashed = generate_hash(value=params["old_password"])
        get_user_auth = UserAuthRepo(connection=self.connection).get_by_user_id_and_password_hash(user_id=get_user[0]["id"], password=old_password_hashed)
        
        if len(get_user_auth) == 0:
            return response(
                body={
                    "message": "Senha antiga invalida"
                },
                code=404
            )
        
        new_password_hashed = generate_hash(value=params["new_password"])
        update_password = UserAuthRepo(connection=self.connection).update_password(user_id=get_user[0]["id"], password=new_password_hashed)
        
        return response(
            body=None,
            code=204
        )