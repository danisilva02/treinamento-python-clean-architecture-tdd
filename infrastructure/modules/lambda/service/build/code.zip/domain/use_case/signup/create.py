# Root
import uuid
import secrets

# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.profile_repo import ProfileRepo
from infra.repository.postgres.contract_repo import ContractRepo
from infra.repository.postgres.acl_repo import ACLRepo
from infra.repository.postgres.user_auth_repo import UserAuthRepo
from infra.repository.postgres.security_repo import SecurityRepo

# Repo Email
from infra.repository.email.resend import EmailRepo

# Utils
from utils.response_domain import response
from utils.md5 import generate_hash
from utils.random import securty_code_generator

def validator_params(params: dict):
    if not "contract_read" in params:
        return response(
            body={
                "message": "Termos é obrigatório"
            }
        )

    if params.get("contract_read") == False:
        return response(
            body={
                "message": "para realizar o cadastro o termos precisa ser aceito"
            }
        )

    if not "name" in params:
        return response(
            body={
                "message": "nome é obrigatório"
            }
        )

    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )
    
    if not "phone_number" in params:
        return response(
            body={
                "message": "Telefone é obrigatório"
            }
        )

    if not "national_id" in params:
        return response(
            body={
                "message": "CPF é obrigatório"
            }
        )
        
    if not "password" in params:
        return response(
            body={
                "message": "Password é obrigatório"
            }
        )

    return None

class Create():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        # Valid Params
        valid = validator_params(params=params)
        if valid != None:
            return valid
        
        # IDs
        user_id = uuid.uuid4()
        user_auth_id = uuid.uuid4()
        profile_id = uuid.uuid4()
        acl_id = uuid.uuid4()
        contract_id = uuid.uuid4()
        security_id = uuid.uuid4()

        user = {
            "id": user_id,
            "email": params.get("email"),
            "national_id": params.get("national_id"),
            "national_id_plus": params.get("national_id_plus"),
            "uuid": uuid.uuid4(),
            "step": "SIGNUP",
            "status": "ACTIVE",
            "provider": "AUTH_DYNAMO",
            "skill": "BASIC",
            "profile_id": uuid.uuid4(),
            "acl_id": uuid.uuid4(),
            "contract_id": uuid.uuid4(),
            "two_factor_id": uuid.uuid4(),
        }

        profile = {
            "id": profile_id,
            "first_name": params.get("name"),
            "country": "Brasil",
            "language": "PT-BR",
            "phone_number": params.get('phone_number'),
            "user_id": user_id
        }

        contract = {
            "id": contract_id,
            "name": "FREE",
            "type": "FREE",
            "status": "ACTIVE",
            "user_id": user_id
        }

        acl = {
            "id": acl_id,
            "name": "USER",
            "status": "ACTIVE",
            "menu_config": { "dashboard": True, "settings": False },
            "user_id": user_id
        }

        user_auth = {
            "id": user_auth_id,
            "password": generate_hash(value=params.get("password")),
            "user_id": user_id
        }

        security = {
            "id": security_id,
            "type": "SIGNUP",
            "status": "AWAIT",
            "code": securty_code_generator(),
            "user_id": user_id
        }

        # Signup
        UserRepo(connection=self.connection).insert(data=user)
        ProfileRepo(connection=self.connection).insert(data=profile)
        ContractRepo(connection=self.connection).insert(data=contract)
        ACLRepo(connection=self.connection).insert(data=acl)
        UserAuthRepo(connection=self.connection).insert(data=user_auth)
        SecurityRepo(connection=self.connection).insert(data=security)

        # Email Welcome
        # EmailRepo().perform(
        #     email=params.get("email"),
        #     subject="Boas vindas",
        #     title="Código Stokado",
        #     message=f"Seu código para continuar o cadastro é <strong>{security['code']}</strong>",
        # )
        
        return response(
            body=user,
            code=200
        )