from infra.repository.postgres.status_repo import Repo

class GetStatus():
    def __init__(self, connection):
        self.connection = connection

    def perform(self):
        get = Repo(
            connection=self.connection
        ).perform()

        return get