# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.security_repo import SecurityRepo

# Utils
from utils.response_domain import response
from utils.random import securty_code_generator

def validator_params(params: dict):
    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )
    
    if not "code" in params:
        return response(
            body={
                "message": "Còdigo é obrigatório"
            }
        )

    return None

class Confirm():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_email(email=params.get("email"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )
        
        valid_code = SecurityRepo(connection=self.connection).valid_code(
            user_id=get_user[0]["id"],
            code=params.get("code"),
            security_type="SIGNUP"
        )

        if len(valid_code) == 0:
            return response(
                body={
                    "message": "Còdigo expirado"
                },
                code=404
            )

        confirm_code = SecurityRepo(connection=self.connection).confirm_code(
            user_id=get_user[0]["id"],
            code=params.get("code"),
            security_type="SIGNUP"
        )
        
        if confirm_code != 1:
            return response(
                body={
                    "message": "Falha ao confirmar còdigo"
                },
                code=404
            )

        finished_user = UserRepo(connection=self.connection).update_status_finished(id=get_user[0]["id"])

        if finished_user != 1:
            return response(
                body={
                    "message": "Falha ao confirmar usuàrio"
                },
                code=404
            )

        return response(
            body={
                "message": "Còdigo confirmado"
            },
            code=200
        )