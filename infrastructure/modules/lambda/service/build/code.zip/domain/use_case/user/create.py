# Root
import uuid
import secrets

# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.profile_repo import ProfileRepo
from infra.repository.postgres.acl_repo import ACLRepo
from infra.repository.postgres.user_auth_repo import UserAuthRepo

# Utils
from utils.response_domain import response
from utils.md5 import generate_hash
from utils.random import password_generator

# Repo Email
from infra.repository.email.resend import EmailRepo

def validator_params(params: dict):
    if not "name" in params:
        return response(
            body={
                "message": "nome é obrigatório"
            }
        )

    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )

    return None

class Create():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid
        
        user_id = uuid.uuid4()
        user_auth_id = uuid.uuid4()
        profile_id = uuid.uuid4()
        acl_id = uuid.uuid4()

        user = {
            "id": user_id,
            "email": params.get("email"),
            "uuid": uuid.uuid4(),
            "step": "COMPLETED",
            "status": "ACTIVE",
            "provider": "LOCAL_AUTH",
            "skill": "PLATFORM",
            "profile_id": uuid.uuid4(),
            "acl_id": uuid.uuid4(),
        }

        profile = {
            "id": profile_id,
            "first_name": params.get("name"),
            "country": "Brasil",
            "language": "PT-BR",
            "user_id": user_id
        }

        acl = {
            "id": acl_id,
            "name": "ADMIN",
            "status": "ACTIVE",
            "menu_config": { "dashboard": True, "settings": True },
            "user_id": user_id
        }

        password = password_generator()

        print("======= Password =========")
        print(password)

        user_auth = {
            "id": user_auth_id,
            "password": generate_hash(password),
            "user_id": user_id
        }

        # Signup
        UserRepo(connection=self.connection).insert(data=user)
        ProfileRepo(connection=self.connection).insert(data=profile)
        ACLRepo(connection=self.connection).insert(data=acl)
        UserAuthRepo(connection=self.connection).insert(data=user_auth)

        # Email Welcome
        # EmailRepo().perform(
        #     email=params.get("email"),
        #     subject="Boas vindas",
        #     title="Senha Plataforma Stokado",
        #     message=f"Sua senha para acessar a plataforma é <strong>{password}</strong>",
        # )

        return response(
            body=user,
            code=200
        )