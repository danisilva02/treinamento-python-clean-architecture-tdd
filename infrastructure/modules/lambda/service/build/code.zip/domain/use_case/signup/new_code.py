# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.security_repo import SecurityRepo

# Repo Email
from infra.repository.email.resend import EmailRepo

# Utils
from utils.response_domain import response
from utils.random import securty_code_generator

def validator_params(params: dict):
    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )

    return None

class NewCode():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_email(email=params.get("email"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )
        
        new_code = SecurityRepo(connection=self.connection).new_code(
            user_id=get_user[0]["id"],
            code=securty_code_generator(),
            security_type="SIGNUP"
        )

        if new_code != 1:
            return response(
                body={
                    "message": "Falha ao gerar novo còdigo"
                },
                code=400
            )

        # Email New Code
        # EmailRepo().perform(
        #     email=params.get("email"),
        #     subject="Boas vindas",
        #     title="Código Stokado",
        #     message=f"Seu código para continuar o cadastro é <strong>{security['code']}</strong>",
        # )

        return response(
            body={
                "message": "Um novo còdigo foi gerado"
            },
            code=200
        )