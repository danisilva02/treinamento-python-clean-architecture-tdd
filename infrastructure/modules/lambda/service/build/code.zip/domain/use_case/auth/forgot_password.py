# Root
import uuid

# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.security_repo import SecurityRepo

# Repo Email
from infra.repository.email.resend import EmailRepo

# Utils
from utils.response_domain import response
from utils.random import securty_code_generator

def validator_params(params: dict):
    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )

    return None

class ForgotPassword():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_email(email=params.get("email"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )
            
        security = {
            "id": uuid.uuid4(),
            "type": "FORGOT_PASSWORD",
            "status": "AWAIT",
            "code": securty_code_generator(),
            "user_id": get_user[0]["id"]
        }
        
        send_email = SecurityRepo(connection=self.connection).insert(data=security)
        print(send_email)
        
        EmailRepo().perform(
            email=params.get("email"),
            subject="Recuperação de senha",
            title="Código Stokado",
            message=f"Seu código é <strong>{security['code']}</strong>",
        )
        
        return response(
            body={
                "message": f"Um còdigo foi emviado para o email: {params.get('email')}"
            },
            code=204
        )