# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo

# Utils
from utils.response_domain import response
from utils.jwt import generate_jwt
from utils.md5 import generate_hash

def validator_params(params: dict):
    if not "user_id" in params:
        return response(
            body={
                "message": "UserId é obrigatório"
            }
        )

    return None

class GetById():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_id(id=params.get("user_id"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )

        if get_user[0]["status"] != "ACTIVE":
            return response(
                body={
                    "message": "Usuário sem permissão"
                },
                code=403
            )

        return response(
            body=get_user[0],
            code=200
        )