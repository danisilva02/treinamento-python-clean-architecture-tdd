# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo
from infra.repository.postgres.user_auth_repo import UserAuthRepo

# Utils
from utils.response_domain import response
from utils.jwt import generate_jwt
from utils.md5 import generate_hash

def validator_params(params: dict):
    if not "email" in params:
        return response(
            body={
                "message": "Email é obrigatório"
            }
        )
    
    if not "password" in params:
        return response(
            body={
                "message": "Password é obrigatório"
            }
        )

    return None

class LoginPlatform():
    def __init__(self, connection):
        self.connection = connection

    def perform(self, params: dict):
        valid = validator_params(params=params)
        if valid != None:
            return valid

        get_user = UserRepo(connection=self.connection).get_by_email(email=params.get("email"))

        if len(get_user) == 0:
            return response(
                body={
                    "message": "Usuário não encontrado"
                },
                code=404
            )

        if get_user[0]["status"] != "ACTIVE" and get_user[0]["skill"] != "ADMIN":
            return response(
                body={
                    "message": "Usuário sem permissão"
                },
                code=403
            )
        
        password_hashed = generate_hash(value=params.get("password"))
        login = UserAuthRepo(connection=self.connection).get_by_user_id_and_password_hash(user_id=get_user[0]["id"], password=password_hashed)

        if len(login) == 0:
            return response(
                body={
                    "message": "Email ou senha incorretos"
                },
                code=404
            )

        token = generate_jwt(user_id=get_user[0]["id"])
        
        return response(
            body={
                "accessToken": token
            },
            code=200
        )