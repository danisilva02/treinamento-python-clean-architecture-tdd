# Repo Postgres
from infra.repository.postgres.user_repo import UserRepo

# Utils
from utils.response_domain import response
from utils.jwt import generate_jwt
from utils.md5 import generate_hash

class Get():
    def __init__(self, connection):
        self.connection = connection

    def perform(self):
        get_users = UserRepo(connection=self.connection).get()

        if len(get_users) == 0:
            return response(
                body={
                    "message": "Usuários não encontrado"
                },
                code=404
            )

        return response(
            body=get_users,
            code=200
        )