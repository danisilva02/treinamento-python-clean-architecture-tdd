from datetime import datetime

class User:
    def __init__(self, id, email, national_id=None, national_id_plus=None, uid=None, step=None, status=None,
                 provider=None, skill=None, created_at=None, updated_at=None, profile_id=None, acl_id=None,
                 contract_id=None, two_factor_id=None):
        self.id = id
        self.email = email
        self.national_id = national_id
        self.national_id_plus = national_id_plus
        self.uid = uid
        self.step = step
        self.status = status
        self.provider = provider
        self.skill = skill
        self.created_at = created_at or datetime.now()
        self.updated_at = updated_at
        self.profile_id = profile_id
        self.acl_id = acl_id
        self.contract_id = contract_id
        self.two_factor_id = two_factor_id

    def __repr__(self):
        return (f"<User(id={self.id}, email={self.email}, national_id={self.national_id}, "
                f"national_id_plus={self.national_id_plus}, uid={self.uid}, step={self.step}, "
                f"status={self.status}, provider={self.provider}, skill={self.skill}, "
                f"created_at={self.created_at}, updated_at={self.updated_at}, profile_id={self.profile_id}, "
                f"acl_id={self.acl_id}, contract_id={self.contract_id}, two_factor_id={self.two_factor_id})>")
