import awsgi
import json
from datetime import datetime
from flask import Flask, g
from flask_cors import CORS

# Utils Middleware
from utils.middleware import middleware

# Infra
from infra.repository.postgres.connection import get_connection as pg_connection

# Routes
from routes.status import status_bp
from routes.user import user_bp
from routes.signup import user_signup_bp
from routes.auth import auth_bp

app = Flask(__name__)
CORS(app)

# Middleware
# app.wsgi_app = middleware(app.wsgi_app)

# Connection Pool PG Global
pool_pg = pg_connection()
@app.before_request
def before_request():
    """A função before_request será executada antes de cada requisição.
    Aqui, pegamos uma conexão do pool e a armazenamos no contexto da requisição."""
    try:
        # Pegue uma conexão do pool e armazene em `g` (contexto de requisição)
        g.db_conn = pool_pg.getconn()
    except Exception as e:
        app.logger.error(f"Erro ao conectar no banco de dados: {e}")
        return "Erro ao conectar no banco de dados", 500

@app.teardown_request
def teardown_request(exception):
    """Função chamada após cada requisição.
    Devolve a conexão para o pool."""
    db_conn = getattr(g, 'db_conn', None)
    if db_conn is not None:
        pool_pg.putconn(db_conn)  # Devolver a conexão ao pool

# Registrar os blueprints
app.register_blueprint(status_bp, url_prefix='/v1/status')
app.register_blueprint(user_signup_bp, url_prefix='/v1/user/signup')
app.register_blueprint(user_bp, url_prefix='/v1/user')
app.register_blueprint(auth_bp, url_prefix='/v1/user/auth')

def lambda_handler(event, context):
    event['httpMethod'] = event['requestContext']['http']['method']
    event['path'] = event['requestContext']['http']['path']
    event['queryStringParameters'] = event.get('queryStringParameters', {})

    return awsgi.response(app, event, context)

if __name__ == "__main__":
    app.run(debug=True)