from flask import Blueprint, g, jsonify

# Domain
from domain.use_case.status.get_status import GetStatus

status_bp = Blueprint('v1/status', __name__)

@status_bp.route('/')
def get_status():
    try:
        get_status = GetStatus(connection=g.db_conn.cursor()).perform()
        return jsonify({"message": "ok", "version": get_status}), 200
    except Exception as e:
        return jsonify({"message": str(e)}), 500

# @status_bp.route('/operation')
# def get_status():
#     try:
#         get_status = GetStatus(connection=g.db_conn.cursor()).perform()
#         return jsonify({"message": "ok", "version": get_status}), 200
#     except Exception as e:
#         return jsonify({"message": str(e)}), 500