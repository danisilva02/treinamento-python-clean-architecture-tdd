from flask import Blueprint, g, jsonify, request

# Domain
from domain.use_case.auth.change_password import ChangePassword
from domain.use_case.auth.forgot_password import ForgotPassword
from domain.use_case.auth.confirm_forgot_password import ConfirmForgotPassword
from domain.use_case.auth.login_app import LoginApp
from domain.use_case.auth.login_platform import LoginPlatform

# Define Route
auth_bp = Blueprint('v1/user/auth', __name__)

# Login App
@auth_bp.route('/app/login', methods=['POST'])
def login_app():
    try:
        perform = LoginApp(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500


# Login Platform
@auth_bp.route('/platform/login', methods=['POST'])
def login_platform():
    try:
        perform = LoginPlatform(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500

# Change Password
@auth_bp.route('/change-password', methods=['POST'])
def change_password():
    try:
        perform = ChangePassword(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500
    
# Forgot Password
@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        perform = ForgotPassword(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500
    
# Confirm Forgot Password
@auth_bp.route('/confirm-forgot-password', methods=['POST'])
def confirm_forgot_password():
    try:
        perform = ConfirmForgotPassword(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500