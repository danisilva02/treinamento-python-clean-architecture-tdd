from flask import Blueprint, g, jsonify, request

# Domain
from domain.use_case.user.create import Create
from domain.use_case.user.get_by_id import GetById
from domain.use_case.user.get import Get

# Define Route
user_bp = Blueprint('v1/user', __name__)

# Create
@user_bp.route('/', methods=['POST'])
def create():
    try:
        perform = Create(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        return jsonify({"message": str(e)}), 500

# Get
@user_bp.route('/', methods=['GET'])
def get():
    try:
        perform = Get(connection=g.db_conn).perform()
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        return jsonify({"message": str(e)}), 500

# Get By ID
@user_bp.route('/<string:user_id>', methods=['GET'])
def get_user_by_id(user_id):
    try:
        perform = GetById(connection=g.db_conn).perform(
            params={
                "user_id": user_id
            }
        )
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        return jsonify({"message": str(e)}), 500

# Get Me
# @user_bp.route('/me', methods=['GET'])
# def get_me(user_id):
#     try:
#         perform = GetById(connection=g.db_conn).perform(
#             params={
#                 "user_id": user_id
#             }
#         )
#         return jsonify(perform["body"]), perform["code"]
#     except Exception as e:
#         return jsonify({"error": str(e)}), 500
