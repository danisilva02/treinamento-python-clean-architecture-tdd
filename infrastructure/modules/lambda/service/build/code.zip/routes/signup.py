from flask import Blueprint, g, jsonify, request

# Domain
from domain.use_case.signup.create import Create
from domain.use_case.signup.confirm import Confirm
from domain.use_case.signup.new_code import NewCode

# Define Route
user_signup_bp = Blueprint('v1/user/signup', __name__)

# Create
@user_signup_bp.route('/', methods=['POST'])
def signup():
    try:
        perform = Create(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500

# Confirm
@user_signup_bp.route('/confirm', methods=['POST'])
def confirm():
    try:
        perform = Confirm(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500

# New Code
@user_signup_bp.route('/new-code', methods=['POST'])
def new_code():
    try:
        perform = NewCode(connection=g.db_conn).perform(params=request.get_json())
        return jsonify(perform["body"]), perform["code"]
    except Exception as e:
        print(e)
        return jsonify({"message": str(e)}), 500
