from flask import Blueprint, jsonify

anouncement_bp = Blueprint('anouncement', __name__)

@anouncement_bp.route('/')
def get_anouncements():
    return jsonify({"message": "Rota de anouncements"}), 200

@anouncement_bp.route('/<int:anouncement_id>')
def get_anouncement_by_id(anouncement_id):
    return jsonify({"message": f"Anouncement {anouncement_id}"}), 200
